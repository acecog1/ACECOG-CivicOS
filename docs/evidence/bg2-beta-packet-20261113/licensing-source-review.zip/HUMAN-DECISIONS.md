# Qualified human decisions required

For EACH dispositions.json row record ACCEPT or REJECT, reviewer name/qualification, exact packet and runtime SHA-256, applicable terms/source/patch findings, rationale, required remediation, expiry/revisit trigger and signed evidence. PENDING is not acceptance. R-CONDITIONAL is not accepted residual risk. A qualified reviewer must separately decide whole-packet legal sufficiency; PMO records appointment and capacity. No automated or Builder legal certification. Owner final beta acceptance and separate publication GO follow their own gates.
